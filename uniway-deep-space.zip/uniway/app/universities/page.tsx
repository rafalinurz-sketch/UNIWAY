import ChanceCalculator from "@/components/universities/ChanceCalculator";
import universities from "@/data/universities.sample.json";
import type { University } from "@/types/university";

export default function UniversitiesPage() {
  return (
    <main className="max-w-7xl mx-auto px-6 py-10">
      <h1 className="font-display text-2xl mb-2">Подбор университетов</h1>
      <p className="text-white/60 mb-8">
        Введите свои баллы, чтобы увидеть категорию Safety / Target / Reach для
        каждого вуза.
      </p>
      <ChanceCalculator universities={universities as University[]} />
    </main>
  );
}
