import type { Metadata } from "next";
import { Space_Grotesk, Inter } from "next/font/google";
import StarfieldCanvas from "@/components/background/StarfieldCanvas";
import "./globals.css";

const displayFont = Space_Grotesk({
  subsets: ["latin"],
  variable: "--font-display",
  weight: ["500", "700"],
});
const textFont = Inter({
  subsets: ["latin", "cyrillic"],
  variable: "--font-text",
});

export const metadata: Metadata = {
  title: "Uniway — SAT/IELTS подготовка и подбор университетов",
  description:
    "Готовься к SAT и IELTS в интерфейсе, вдохновлённом космосом, и находи университеты под свои баллы.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ru" className={`${displayFont.variable} ${textFont.variable}`}>
      <body className="min-h-screen font-text antialiased">
        <StarfieldCanvas />
        <div className="relative z-10">{children}</div>
      </body>
    </html>
  );
}
