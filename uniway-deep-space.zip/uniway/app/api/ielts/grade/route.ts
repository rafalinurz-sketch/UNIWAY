import { NextRequest, NextResponse } from "next/server";
import { gradeIeltsSubmission } from "@/lib/ielts-grading";
import type { IeltsGradingRequest } from "@/types/ielts";

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as IeltsGradingRequest;

    if (!body.submission || !body.bandDescriptors) {
      return NextResponse.json({ error: "Некорректный запрос" }, { status: 400 });
    }

    const result = await gradeIeltsSubmission(body);
    return NextResponse.json(result);
  } catch (err) {
    console.error("IELTS grading error:", err);
    return NextResponse.json(
      { error: "Не удалось выполнить оценку" },
      { status: 500 }
    );
  }
}
