import AdminDashboard, { DashboardStats } from "@/components/admin/AdminDashboard";

// В проде: замените на серверный fetch к вашей БД/API,
// например через Prisma: await prisma.user.count(), агрегации по Click и т.д.
const mockStats: DashboardStats = {
  dailyActiveUsers: [
    { date: "18 сен", users: 120 },
    { date: "19 сен", users: 145 },
    { date: "20 сен", users: 132 },
    { date: "21 сен", users: 168 },
    { date: "22 сен", users: 190 },
    { date: "23 сен", users: 210 },
    { date: "24 сен", users: 205 },
  ],
  avgSimulatorScores: [
    { module: "SAT Math", avgScore: 640 },
    { module: "SAT R&W", avgScore: 610 },
    { module: "IELTS Writing", avgScore: 6.5 },
    { module: "IELTS Speaking", avgScore: 6.8 },
  ],
  universityClicks: [
    { university: "MIT", clicks: 412 },
    { university: "University of Toronto", clicks: 298 },
    { university: "Nazarbayev University", clicks: 540 },
  ],
  totals: {
    totalUsers: 3820,
    totalAttempts: 15420,
    avgSessionMinutes: 24,
    newUsersThisWeek: 187,
  },
};

export default function AdminPage() {
  return (
    <main className="max-w-7xl mx-auto px-6 py-10">
      <h1 className="font-display text-2xl mb-6">Панель администратора</h1>
      <AdminDashboard stats={mockStats} />
    </main>
  );
}
