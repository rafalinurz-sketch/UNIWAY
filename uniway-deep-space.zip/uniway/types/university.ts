export interface AdmissionRequirements {
  minIeltsOverall: number | null; // null = IELTS не требуется / TOEFL альтернатива
  minSatTotal: number | null; // 400-1600
  minGpa: number | null; // по 4.0 шкале
  acceptsSatOptional: boolean;
}

export interface FinancialAid {
  needBlind: boolean; // приём не зависит от способности платить
  needBlindForInternational: boolean; // отдельно — важно для СНГ-абитуриентов
  fullRideAvailable: boolean; // покрывает 100% (обучение+проживание+перелёт)
  meritScholarshipMaxPercent: number; // макс. % покрытия за академические заслуги
}

export interface Deadline {
  round: "Early Decision" | "Early Action" | "Regular Decision" | "Rolling";
  date: string; // ISO date "2027-01-01"
}

export interface University {
  id: string;
  name: string;
  country: string;
  city: string;
  logoUrl: string;
  heroImageUrl: string;
  worldRanking: number | null; // QS/THE ranking, null если не ранжирован
  acceptanceRatePercent: number;
  annualCostUsd: number; // полная стоимость до стипендий (tuition + room & board)
  requirements: AdmissionRequirements;
  financialAid: FinancialAid;
  deadlines: Deadline[];
  popularMajors: string[];
  tags: ("Ivy League" | "Public" | "Private" | "Liberal Arts" | "STEM-focused")[];
  websiteUrl: string;
}

/**
 * Prisma-схема (для справки — сохраните как prisma/schema.prisma и адаптируйте
 * под ваш Postgres/Supabase). JSON-поля используют встроенный Json тип Prisma.
 *
 * model University {
 *   id                        String   @id @default(cuid())
 *   name                      String
 *   country                   String
 *   city                      String
 *   logoUrl                   String
 *   heroImageUrl              String
 *   worldRanking              Int?
 *   acceptanceRatePercent     Float
 *   annualCostUsd             Int
 *   minIeltsOverall           Float?
 *   minSatTotal               Int?
 *   minGpa                    Float?
 *   acceptsSatOptional        Boolean  @default(false)
 *   needBlind                 Boolean  @default(false)
 *   needBlindForInternational Boolean  @default(false)
 *   fullRideAvailable         Boolean  @default(false)
 *   meritScholarshipMaxPercent Int     @default(0)
 *   deadlines                 Json     // Deadline[]
 *   popularMajors             String[]
 *   tags                      String[]
 *   websiteUrl                String
 *   clicks                    Click[]
 *   createdAt                 DateTime @default(now())
 *   updatedAt                 DateTime @updatedAt
 * }
 *
 * model Click {
 *   id           String     @id @default(cuid())
 *   universityId String
 *   university   University @relation(fields: [universityId], references: [id])
 *   userId       String?
 *   createdAt    DateTime   @default(now())
 * }
 */
