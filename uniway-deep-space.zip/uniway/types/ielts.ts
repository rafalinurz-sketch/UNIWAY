export type IeltsSkill = "writing" | "speaking";
export type IeltsTask = "task1" | "task2" | "part1" | "part2" | "part3";

// 4 официальных критерия IELTS (Writing и Speaking используют разные названия
// для 3-го и 4-го критерия, поэтому объединяем через union-ключи)
export interface IeltsWritingCriteria {
  taskAchievement: number; // 0-9, шаг 0.5 (для Task 1 — Task Achievement, для Task 2 — Task Response)
  coherenceCohesion: number;
  lexicalResource: number;
  grammaticalRangeAccuracy: number;
}

export interface IeltsSpeakingCriteria {
  fluencyCoherence: number;
  lexicalResource: number;
  grammaticalRangeAccuracy: number;
  pronunciation: number;
}

export interface IeltsSubmissionPayload {
  userId: string;
  skill: IeltsSkill;
  task: IeltsTask;
  promptText: string; // формулировка задания, которое видел студент
  // Writing: текст эссе. Speaking: транскрипт (после STT) + ссылка на аудиофайл
  responseText?: string;
  audioUrl?: string;
  durationSeconds?: number;
  wordCount?: number;
}

// Структура, которую бэкенд отправляет в AI API (например, Claude) для оценки
export interface IeltsGradingRequest {
  submission: IeltsSubmissionPayload;
  bandDescriptors: "writing" | "speaking"; // какой набор дескрипторов IELTS подставить в system prompt
}

export interface IeltsGradingResult {
  overallBand: number;
  criteria: IeltsWritingCriteria | IeltsSpeakingCriteria;
  feedback: {
    summary: string;
    strengths: string[];
    improvements: string[];
    correctedExamples?: { original: string; suggestion: string; reason: string }[];
  };
  gradedAt: string; // ISO date
  modelVersion: string; // например "claude-sonnet-4-6"
}
