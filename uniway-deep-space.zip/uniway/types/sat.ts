export type SatModule = "reading-writing-1" | "reading-writing-2" | "math-1" | "math-2";

export type QuestionStatus = "unseen" | "answered" | "flagged" | "skipped";

export interface SatChoice {
  id: "A" | "B" | "C" | "D";
  text: string;
}

export interface SatQuestion {
  id: string;
  module: SatModule;
  passage?: string; // текст для Reading/Writing, отсутствует для Math
  prompt: string;
  choices: SatChoice[];
  correctChoiceId: SatChoice["id"];
  explanation: string;
  allowsCalculator: boolean; // Math модуль 2 в реальном SAT разрешает калькулятор на всё
}

export interface SatSectionConfig {
  module: SatModule;
  title: string;
  durationSeconds: number; // Bluebook: RW ~32 мин/модуль, Math ~35 мин/модуль
  questions: SatQuestion[];
}

export interface SatAttemptState {
  answers: Record<string, SatChoice["id"] | undefined>;
  statuses: Record<string, QuestionStatus>;
  currentIndex: number;
  timeRemainingSeconds: number;
}
