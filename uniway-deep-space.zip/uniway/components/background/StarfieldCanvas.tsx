"use client";

import { useEffect, useRef } from "react";

/**
 * StarfieldCanvas — фон "глубокий космос" для Uniway.
 * - Статичное поле мерцающих звёзд (плотность зависит от площади экрана)
 * - Редкие пролетающие кометы (с хвостом, случайный интервал)
 * - Полностью на <canvas>, без сторонних либ — дёшево по производительности
 * - Уважает prefers-reduced-motion: звёзды рисуются один раз, кометы отключены
 *
 * Использование: положить как fixed inset-0 -z-10 позади контента страницы.
 *   <StarfieldCanvas />
 *   <main className="relative z-10">...</main>
 */

interface Star {
  x: number;
  y: number;
  radius: number;
  baseAlpha: number;
  twinkleSpeed: number;
  phase: number;
}

interface Comet {
  x: number;
  y: number;
  vx: number;
  vy: number;
  length: number;
  life: number;
  maxLife: number;
  color: string;
}

const COMET_COLORS = ["#A855F7", "#06B6D4", "#EC4899"];

export default function StarfieldCanvas() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const prefersReducedMotion = window.matchMedia(
      "(prefers-reduced-motion: reduce)"
    ).matches;

    let stars: Star[] = [];
    let comets: Comet[] = [];
    let animationId = 0;
    let width = 0;
    let height = 0;
    let nextCometAt = 0;

    function resize() {
      width = window.innerWidth;
      height = window.innerHeight;
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas!.width = width * dpr;
      canvas!.height = height * dpr;
      canvas!.style.width = `${width}px`;
      canvas!.style.height = `${height}px`;
      ctx!.setTransform(dpr, 0, 0, dpr, 0, 0);

      const density = (width * height) / 9000; // ~плотность звёзд
      stars = Array.from({ length: Math.round(density) }, () => ({
        x: Math.random() * width,
        y: Math.random() * height,
        radius: Math.random() * 1.4 + 0.3,
        baseAlpha: Math.random() * 0.6 + 0.3,
        twinkleSpeed: Math.random() * 0.02 + 0.005,
        phase: Math.random() * Math.PI * 2,
      }));
    }

    function spawnComet() {
      const fromLeft = Math.random() > 0.5;
      const y = Math.random() * height * 0.5;
      comets.push({
        x: fromLeft ? -50 : width + 50,
        y,
        vx: (fromLeft ? 1 : -1) * (4 + Math.random() * 3),
        vy: 1.5 + Math.random() * 1.5,
        length: 120 + Math.random() * 80,
        life: 0,
        maxLife: 140,
        color: COMET_COLORS[Math.floor(Math.random() * COMET_COLORS.length)],
      });
    }

    function drawStaticStars() {
      ctx!.clearRect(0, 0, width, height);
      for (const s of stars) {
        ctx!.beginPath();
        ctx!.arc(s.x, s.y, s.radius, 0, Math.PI * 2);
        ctx!.fillStyle = `rgba(255,255,255,${s.baseAlpha})`;
        ctx!.fill();
      }
    }

    function tick(time: number) {
      ctx!.clearRect(0, 0, width, height);

      // Звёзды с мерцанием
      for (const s of stars) {
        const alpha =
          s.baseAlpha * (0.6 + 0.4 * Math.sin(time * s.twinkleSpeed + s.phase));
        ctx!.beginPath();
        ctx!.arc(s.x, s.y, s.radius, 0, Math.PI * 2);
        ctx!.fillStyle = `rgba(255,255,255,${Math.max(alpha, 0)})`;
        ctx!.fill();
      }

      // Кометы
      if (time > nextCometAt) {
        spawnComet();
        nextCometAt = time + 4000 + Math.random() * 6000;
      }

      comets = comets.filter((c) => c.life < c.maxLife);
      for (const c of comets) {
        c.x += c.vx;
        c.y += c.vy;
        c.life += 1;

        const tailX = c.x - Math.sign(c.vx) * c.length;
        const tailY = c.y - c.length * 0.35;
        const gradient = ctx!.createLinearGradient(c.x, c.y, tailX, tailY);
        gradient.addColorStop(0, c.color);
        gradient.addColorStop(1, "rgba(0,0,0,0)");

        ctx!.strokeStyle = gradient;
        ctx!.lineWidth = 2;
        ctx!.beginPath();
        ctx!.moveTo(c.x, c.y);
        ctx!.lineTo(tailX, tailY);
        ctx!.stroke();

        ctx!.beginPath();
        ctx!.arc(c.x, c.y, 2, 0, Math.PI * 2);
        ctx!.fillStyle = "#fff";
        ctx!.shadowBlur = 12;
        ctx!.shadowColor = c.color;
        ctx!.fill();
        ctx!.shadowBlur = 0;
      }

      animationId = requestAnimationFrame(tick);
    }

    resize();
    window.addEventListener("resize", resize);

    if (prefersReducedMotion) {
      drawStaticStars();
    } else {
      nextCometAt = 3000;
      animationId = requestAnimationFrame(tick);
    }

    return () => {
      window.removeEventListener("resize", resize);
      cancelAnimationFrame(animationId);
    };
  }, []);

  return (
    <div className="fixed inset-0 -z-10 bg-space-void bg-nebula-gradient overflow-hidden">
      <canvas ref={canvasRef} className="block" aria-hidden="true" />
    </div>
  );
}
