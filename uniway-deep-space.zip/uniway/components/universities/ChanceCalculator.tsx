"use client";

import { useMemo, useState } from "react";
import GlassCard from "@/components/ui/GlassCard";
import UniversityCard from "@/components/universities/UniversityCard";
import { calculateChance, UserScores, ChanceCategory } from "@/lib/chance-calculator";
import type { University } from "@/types/university";

interface ChanceCalculatorProps {
  universities: University[];
}

const categoryColor: Record<ChanceCategory, string> = {
  Safety: "text-accent-cyan",
  Target: "text-accent-violet",
  Reach: "text-accent-pink",
};

export default function ChanceCalculator({ universities }: ChanceCalculatorProps) {
  const [scores, setScores] = useState<UserScores>({});
  const [countryFilter, setCountryFilter] = useState<string>("all");
  const [categoryFilter, setCategoryFilter] = useState<ChanceCategory | "all">("all");

  const countries = useMemo(
    () => Array.from(new Set(universities.map((u) => u.country))),
    [universities]
  );

  const results = useMemo(() => {
    return universities
      .filter((u) => countryFilter === "all" || u.country === countryFilter)
      .map((u) => ({ university: u, chance: calculateChance(u, scores) }))
      .filter((r) => categoryFilter === "all" || r.chance.category === categoryFilter);
  }, [universities, scores, countryFilter, categoryFilter]);

  return (
    <div className="space-y-8">
      {/* Ввод баллов пользователя */}
      <GlassCard aurora glow="violet">
        <h2 className="font-display text-xl mb-4">Ваши баллы</h2>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <ScoreInput
            label="IELTS Overall"
            max={9}
            step={0.5}
            value={scores.ielts}
            onChange={(v) => setScores((s) => ({ ...s, ielts: v }))}
          />
          <ScoreInput
            label="SAT Total"
            max={1600}
            step={10}
            value={scores.sat}
            onChange={(v) => setScores((s) => ({ ...s, sat: v }))}
          />
          <ScoreInput
            label="GPA"
            max={4}
            step={0.1}
            value={scores.gpa}
            onChange={(v) => setScores((s) => ({ ...s, gpa: v }))}
          />
        </div>
      </GlassCard>

      {/* Фильтры */}
      <div className="flex flex-wrap gap-3">
        <select
          value={countryFilter}
          onChange={(e) => setCountryFilter(e.target.value)}
          className="glass-panel px-4 py-2 text-sm bg-space-surface"
        >
          <option value="all">Все страны</option>
          {countries.map((c) => (
            <option key={c} value={c}>
              {c}
            </option>
          ))}
        </select>

        <div className="flex gap-2">
          {(["all", "Safety", "Target", "Reach"] as const).map((cat) => (
            <button
              key={cat}
              onClick={() => setCategoryFilter(cat)}
              className={`px-4 py-2 rounded-xl text-sm border transition-all ${
                categoryFilter === cat
                  ? "border-accent-violet bg-accent-violet/10 shadow-glow-violet"
                  : "border-white/10 text-white/60 hover:border-white/25"
              }`}
            >
              {cat === "all" ? "Все" : cat}
            </button>
          ))}
        </div>
      </div>

      {/* Результаты */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {results.map(({ university, chance }) => (
          <UniversityCard
            key={university.id}
            university={university}
            chance={chance}
          />
        ))}
        {results.length === 0 && (
          <p className="text-white/50 col-span-full text-center py-10">
            Нет университетов по выбранным фильтрам — попробуйте изменить критерии.
          </p>
        )}
      </div>
    </div>
  );
}

function ScoreInput({
  label,
  max,
  step,
  value,
  onChange,
}: {
  label: string;
  max: number;
  step: number;
  value?: number;
  onChange: (v: number) => void;
}) {
  return (
    <label className="flex flex-col gap-2 text-sm text-white/70">
      {label}
      <input
        type="number"
        min={0}
        max={max}
        step={step}
        value={value ?? ""}
        onChange={(e) => onChange(parseFloat(e.target.value))}
        className="glass-panel px-3 py-2 bg-transparent focus-visible:outline-2 focus-visible:outline-accent-cyan"
        placeholder={`0 – ${max}`}
      />
    </label>
  );
}
