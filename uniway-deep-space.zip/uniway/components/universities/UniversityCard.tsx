"use client";

import Image from "next/image";
import { motion } from "framer-motion";
import { Sparkles, Calendar, Wallet } from "lucide-react";
import GlassCard from "@/components/ui/GlassCard";
import type { University } from "@/types/university";
import type { ChanceResult } from "@/lib/chance-calculator";

interface UniversityCardProps {
  university: University;
  chance?: ChanceResult;
  onClick?: () => void;
}

const categoryStyles = {
  Safety: { label: "Safety", glow: "cyan" as const, dot: "bg-accent-cyan" },
  Target: { label: "Target", glow: "violet" as const, dot: "bg-accent-violet" },
  Reach: { label: "Reach", glow: "pink" as const, dot: "bg-accent-pink" },
};

export default function UniversityCard({
  university,
  chance,
  onClick,
}: UniversityCardProps) {
  const style = chance ? categoryStyles[chance.category] : undefined;

  return (
    <GlassCard
      aurora
      glow={style?.glow ?? "violet"}
      className="group cursor-pointer relative overflow-hidden"
    >
      <button onClick={onClick} className="w-full text-left" aria-label={university.name}>
        {/* Декоративное "звёздное" свечение при ховере */}
        <motion.div
          className="pointer-events-none absolute -top-10 -right-10 w-32 h-32 rounded-full bg-accent-violet/25 blur-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-500"
        />

        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 rounded-xl bg-white/5 flex items-center justify-center overflow-hidden">
            <Image
              src={university.logoUrl}
              alt={`Логотип ${university.name}`}
              width={40}
              height={40}
            />
          </div>
          <div>
            <h3 className="font-display leading-tight">{university.name}</h3>
            <p className="text-xs text-white/50">
              {university.city}, {university.country}
            </p>
          </div>
        </div>

        {chance && (
          <div className="flex items-center gap-2 mb-3">
            <span className={`w-2 h-2 rounded-full ${style!.dot}`} />
            <span className="text-sm font-medium">{style!.label}</span>
            <span className="text-xs text-white/40">· индекс {chance.score}</span>
          </div>
        )}

        <div className="grid grid-cols-2 gap-3 text-xs text-white/60 mb-4">
          <Stat label="World Ranking" value={university.worldRanking ? `#${university.worldRanking}` : "—"} />
          <Stat label="Acceptance" value={`${university.acceptanceRatePercent}%`} />
          <Stat
            label="Min IELTS"
            value={university.requirements.minIeltsOverall?.toString() ?? "—"}
          />
          <Stat
            label="Min SAT"
            value={university.requirements.minSatTotal?.toString() ?? "—"}
          />
        </div>

        <div className="flex flex-wrap gap-2 mb-4">
          {university.financialAid.needBlind && <Badge icon={<Sparkles size={11} />} label="Need-Blind" />}
          {university.financialAid.fullRideAvailable && (
            <Badge icon={<Wallet size={11} />} label="Full-Ride" />
          )}
        </div>

        <div className="flex items-center gap-1.5 text-xs text-white/40">
          <Calendar size={12} />
          Дедлайн: {university.deadlines[0]?.round} —{" "}
          {new Date(university.deadlines[0]?.date).toLocaleDateString("ru-RU")}
        </div>
      </button>
    </GlassCard>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <div className="text-white/40">{label}</div>
      <div className="text-white/90 font-medium">{value}</div>
    </div>
  );
}

function Badge({ icon, label }: { icon: React.ReactNode; label: string }) {
  return (
    <span className="flex items-center gap-1 text-[11px] px-2 py-1 rounded-full bg-accent-violet/10 text-accent-violet border border-accent-violet/30">
      {icon}
      {label}
    </span>
  );
}
