"use client";

import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
} from "recharts";
import GlassCard from "@/components/ui/GlassCard";

export interface DashboardStats {
  dailyActiveUsers: { date: string; users: number }[];
  avgSimulatorScores: { module: "SAT Math" | "SAT R&W" | "IELTS Writing" | "IELTS Speaking"; avgScore: number }[];
  universityClicks: { university: string; clicks: number }[];
  totals: {
    totalUsers: number;
    totalAttempts: number;
    avgSessionMinutes: number;
    newUsersThisWeek: number;
  };
}

const chartTooltipStyle = {
  background: "#12131A",
  border: "1px solid rgba(255,255,255,0.1)",
  borderRadius: "12px",
  color: "#fff",
};

/**
 * AdminDashboard — главная страница /admin. Данные приходят с сервера
 * (например GET /api/admin/stats), здесь — чисто презентационный компонент.
 */
export default function AdminDashboard({ stats }: { stats: DashboardStats }) {
  return (
    <div className="space-y-8">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <KpiCard label="Всего пользователей" value={stats.totals.totalUsers} glow="violet" />
        <KpiCard label="Попыток симуляторов" value={stats.totals.totalAttempts} glow="cyan" />
        <KpiCard
          label="Ср. время сессии"
          value={`${stats.totals.avgSessionMinutes} мин`}
          glow="pink"
        />
        <KpiCard
          label="Новых за неделю"
          value={`+${stats.totals.newUsersThisWeek}`}
          glow="violet"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <GlassCard glow="cyan">
          <h3 className="font-display text-lg mb-4">Активность пользователей (DAU)</h3>
          <ResponsiveContainer width="100%" height={260}>
            <AreaChart data={stats.dailyActiveUsers}>
              <defs>
                <linearGradient id="dauGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#06B6D4" stopOpacity={0.5} />
                  <stop offset="100%" stopColor="#06B6D4" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid stroke="rgba(255,255,255,0.06)" vertical={false} />
              <XAxis dataKey="date" stroke="rgba(255,255,255,0.4)" fontSize={12} />
              <YAxis stroke="rgba(255,255,255,0.4)" fontSize={12} />
              <Tooltip contentStyle={chartTooltipStyle} />
              <Area
                type="monotone"
                dataKey="users"
                stroke="#06B6D4"
                fill="url(#dauGradient)"
                strokeWidth={2}
              />
            </AreaChart>
          </ResponsiveContainer>
        </GlassCard>

        <GlassCard glow="violet">
          <h3 className="font-display text-lg mb-4">Средний балл по симуляторам</h3>
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={stats.avgSimulatorScores}>
              <CartesianGrid stroke="rgba(255,255,255,0.06)" vertical={false} />
              <XAxis dataKey="module" stroke="rgba(255,255,255,0.4)" fontSize={11} />
              <YAxis stroke="rgba(255,255,255,0.4)" fontSize={12} />
              <Tooltip contentStyle={chartTooltipStyle} />
              <Bar dataKey="avgScore" fill="#A855F7" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </GlassCard>
      </div>

      <GlassCard glow="pink">
        <h3 className="font-display text-lg mb-4">Клики по университетам</h3>
        <ResponsiveContainer width="100%" height={280}>
          <BarChart data={stats.universityClicks} layout="vertical">
            <CartesianGrid stroke="rgba(255,255,255,0.06)" horizontal={false} />
            <XAxis type="number" stroke="rgba(255,255,255,0.4)" fontSize={12} />
            <YAxis
              type="category"
              dataKey="university"
              stroke="rgba(255,255,255,0.4)"
              fontSize={12}
              width={160}
            />
            <Tooltip contentStyle={chartTooltipStyle} />
            <Bar dataKey="clicks" fill="#EC4899" radius={[0, 8, 8, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </GlassCard>
    </div>
  );
}

function KpiCard({
  label,
  value,
  glow,
}: {
  label: string;
  value: string | number;
  glow: "violet" | "cyan" | "pink";
}) {
  return (
    <GlassCard glow={glow} className="text-center">
      <div className="text-2xl font-display">{value}</div>
      <div className="text-xs text-white/50 mt-1">{label}</div>
    </GlassCard>
  );
}
