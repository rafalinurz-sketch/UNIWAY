"use client";

import { useState } from "react";
import { Plus, Trash2, Save, BookOpen, GraduationCap } from "lucide-react";
import GlassCard from "@/components/ui/GlassCard";
import GlowButton from "@/components/ui/GlowButton";
import type { SatQuestion, SatModule, SatChoice } from "@/types/sat";

type ContentTab = "sat-questions" | "universities";

interface ContentBuilderProps {
  initialQuestions: SatQuestion[];
  onSaveQuestion: (question: SatQuestion) => Promise<void>;
  onDeleteQuestion: (id: string) => Promise<void>;
}

const emptyQuestion = (module: SatModule): SatQuestion => ({
  id: crypto.randomUUID(),
  module,
  prompt: "",
  choices: [
    { id: "A", text: "" },
    { id: "B", text: "" },
    { id: "C", text: "" },
    { id: "D", text: "" },
  ],
  correctChoiceId: "A",
  explanation: "",
  allowsCalculator: false,
});

/**
 * ContentBuilder — вкладка /admin/content. CRUD для вопросов SAT (Reading/Writing
 * и Math) прямо в интерфейсе. Раздел "universities" — точка расширения для
 * редактирования карточек вузов (форма аналогичной структуры на базе University type).
 */
export default function ContentBuilder({
  initialQuestions,
  onSaveQuestion,
  onDeleteQuestion,
}: ContentBuilderProps) {
  const [tab, setTab] = useState<ContentTab>("sat-questions");
  const [questions, setQuestions] = useState(initialQuestions);
  const [draft, setDraft] = useState<SatQuestion>(emptyQuestion("math-1"));
  const [isSaving, setIsSaving] = useState(false);

  async function handleSave() {
    if (!draft.prompt.trim()) return;
    setIsSaving(true);
    try {
      await onSaveQuestion(draft);
      setQuestions((qs) => {
        const exists = qs.some((q) => q.id === draft.id);
        return exists
          ? qs.map((q) => (q.id === draft.id ? draft : q))
          : [...qs, draft];
      });
      setDraft(emptyQuestion(draft.module));
    } finally {
      setIsSaving(false);
    }
  }

  async function handleDelete(id: string) {
    await onDeleteQuestion(id);
    setQuestions((qs) => qs.filter((q) => q.id !== id));
  }

  function updateChoice(choiceId: SatChoice["id"], text: string) {
    setDraft((d) => ({
      ...d,
      choices: d.choices.map((c) => (c.id === choiceId ? { ...c, text } : c)),
    }));
  }

  return (
    <div className="space-y-6">
      <div className="flex gap-2">
        <TabButton
          active={tab === "sat-questions"}
          icon={<BookOpen size={14} />}
          label="Вопросы SAT/IELTS"
          onClick={() => setTab("sat-questions")}
        />
        <TabButton
          active={tab === "universities"}
          icon={<GraduationCap size={14} />}
          label="Университеты"
          onClick={() => setTab("universities")}
        />
      </div>

      {tab === "sat-questions" ? (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Форма создания/редактирования */}
          <GlassCard aurora glow="violet">
            <h3 className="font-display text-lg mb-4">Новый вопрос</h3>

            <div className="space-y-3">
              <select
                value={draft.module}
                onChange={(e) =>
                  setDraft((d) => ({ ...d, module: e.target.value as SatModule }))
                }
                className="w-full glass-panel px-3 py-2 bg-space-surface text-sm"
              >
                <option value="math-1">Math — модуль 1</option>
                <option value="math-2">Math — модуль 2</option>
                <option value="reading-writing-1">Reading & Writing — модуль 1</option>
                <option value="reading-writing-2">Reading & Writing — модуль 2</option>
              </select>

              {draft.module.startsWith("reading") && (
                <textarea
                  value={draft.passage ?? ""}
                  onChange={(e) => setDraft((d) => ({ ...d, passage: e.target.value }))}
                  placeholder="Текст passage…"
                  className="w-full h-28 glass-panel px-3 py-2 bg-transparent text-sm resize-none"
                />
              )}

              <textarea
                value={draft.prompt}
                onChange={(e) => setDraft((d) => ({ ...d, prompt: e.target.value }))}
                placeholder="Формулировка вопроса…"
                className="w-full h-20 glass-panel px-3 py-2 bg-transparent text-sm resize-none"
              />

              {draft.choices.map((choice) => (
                <div key={choice.id} className="flex items-center gap-2">
                  <button
                    onClick={() =>
                      setDraft((d) => ({ ...d, correctChoiceId: choice.id }))
                    }
                    className={`w-7 h-7 rounded-full text-xs flex items-center justify-center border ${
                      draft.correctChoiceId === choice.id
                        ? "bg-accent-cyan border-accent-cyan text-space-void"
                        : "border-white/20 text-white/50"
                    }`}
                    title="Отметить как правильный ответ"
                  >
                    {choice.id}
                  </button>
                  <input
                    value={choice.text}
                    onChange={(e) => updateChoice(choice.id, e.target.value)}
                    placeholder={`Вариант ${choice.id}`}
                    className="flex-1 glass-panel px-3 py-2 bg-transparent text-sm"
                  />
                </div>
              ))}

              <textarea
                value={draft.explanation}
                onChange={(e) =>
                  setDraft((d) => ({ ...d, explanation: e.target.value }))
                }
                placeholder="Объяснение правильного ответа…"
                className="w-full h-16 glass-panel px-3 py-2 bg-transparent text-sm resize-none"
              />

              <label className="flex items-center gap-2 text-xs text-white/60">
                <input
                  type="checkbox"
                  checked={draft.allowsCalculator}
                  onChange={(e) =>
                    setDraft((d) => ({ ...d, allowsCalculator: e.target.checked }))
                  }
                />
                Разрешить калькулятор для этого вопроса
              </label>

              <GlowButton
                onClick={handleSave}
                disabled={isSaving}
                className="w-full flex items-center justify-center gap-2"
              >
                <Save size={15} /> Сохранить вопрос
              </GlowButton>
            </div>
          </GlassCard>

          {/* Список существующих вопросов */}
          <GlassCard glow="cyan" className="max-h-[640px] overflow-auto">
            <h3 className="font-display text-lg mb-4">
              База вопросов ({questions.length})
            </h3>
            <div className="space-y-2">
              {questions.map((q) => (
                <div
                  key={q.id}
                  className="flex items-start justify-between gap-3 p-3 rounded-xl bg-white/[0.03] border border-white/5"
                >
                  <div className="flex-1 min-w-0">
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-white/5 text-white/40 mr-2">
                      {q.module}
                    </span>
                    <p className="text-sm text-white/80 truncate">{q.prompt}</p>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={() => setDraft(q)}
                      className="text-xs text-accent-cyan hover:underline"
                    >
                      Изменить
                    </button>
                    <button
                      onClick={() => handleDelete(q.id)}
                      className="text-white/40 hover:text-accent-pink"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                </div>
              ))}
              {questions.length === 0 && (
                <p className="text-white/40 text-sm text-center py-6">
                  Пока нет вопросов — добавьте первый слева.
                </p>
              )}
            </div>
          </GlassCard>
        </div>
      ) : (
        <GlassCard glow="pink">
          <p className="text-white/60 text-sm">
            Редактор университетов использует ту же CRUD-логику: форма на базе типа{" "}
            <code className="text-accent-cyan">University</code> (types/university.ts)
            + список карточек с кнопками "Изменить"/"Удалить", как для вопросов слева.
            Вынесите общий паттерн формы в переиспользуемый{" "}
            <code className="text-accent-cyan">useCrudForm</code> hook, если нужно
            добавить больше типов контента (например, IELTS-темы или флеш-карточки).
          </p>
        </GlassCard>
      )}
    </div>
  );
}

function TabButton({
  active,
  icon,
  label,
  onClick,
}: {
  active: boolean;
  icon: React.ReactNode;
  label: string;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm transition-all ${
        active
          ? "bg-accent-violet/15 text-white border border-accent-violet/50 shadow-glow-violet"
          : "text-white/50 border border-transparent hover:border-white/10"
      }`}
    >
      {icon}
      {label}
    </button>
  );
}
