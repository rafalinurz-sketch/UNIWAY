"use client";

import { useMemo, useState } from "react";
import { Search, KeyRound, ShieldCheck, MoreVertical } from "lucide-react";
import GlassCard from "@/components/ui/GlassCard";

export type UserRole = "student" | "moderator" | "admin";

export interface AdminUserRow {
  id: string;
  fullName: string;
  email: string;
  role: UserRole;
  satAttempts: number;
  ieltsAttempts: number;
  bestSatScore: number | null;
  bestIeltsBand: number | null;
  lastActiveAt: string; // ISO
}

interface UsersTableProps {
  users: AdminUserRow[];
  onResetPassword: (userId: string) => Promise<void>;
  onChangeRole: (userId: string, role: UserRole) => Promise<void>;
}

/**
 * UsersTable — вкладка /admin/users. Поиск, просмотр прогресса, сброс пароля
 * и смена роли. Действия — заглушки под ваши серверные экшены/API-роуты.
 */
export default function UsersTable({
  users,
  onResetPassword,
  onChangeRole,
}: UsersTableProps) {
  const [query, setQuery] = useState("");
  const [openMenuId, setOpenMenuId] = useState<string | null>(null);

  const filtered = useMemo(
    () =>
      users.filter(
        (u) =>
          u.fullName.toLowerCase().includes(query.toLowerCase()) ||
          u.email.toLowerCase().includes(query.toLowerCase())
      ),
    [users, query]
  );

  return (
    <GlassCard glow="violet" className="overflow-hidden">
      <div className="flex items-center gap-2 mb-4">
        <Search size={16} className="text-white/40" />
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Поиск по имени или почте…"
          className="bg-transparent outline-none text-sm w-full text-white/90 placeholder:text-white/30"
        />
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-white/40 border-b border-white/10">
              <th className="py-2 pr-4 font-normal">Пользователь</th>
              <th className="py-2 pr-4 font-normal">Роль</th>
              <th className="py-2 pr-4 font-normal">SAT (попыток / лучший)</th>
              <th className="py-2 pr-4 font-normal">IELTS (попыток / band)</th>
              <th className="py-2 pr-4 font-normal">Активность</th>
              <th className="py-2 font-normal" />
            </tr>
          </thead>
          <tbody>
            {filtered.map((u) => (
              <tr key={u.id} className="border-b border-white/5 hover:bg-white/[0.03]">
                <td className="py-3 pr-4">
                  <div className="font-medium">{u.fullName}</div>
                  <div className="text-white/40 text-xs">{u.email}</div>
                </td>
                <td className="py-3 pr-4">
                  <RoleBadge role={u.role} />
                </td>
                <td className="py-3 pr-4 text-white/70">
                  {u.satAttempts} / {u.bestSatScore ?? "—"}
                </td>
                <td className="py-3 pr-4 text-white/70">
                  {u.ieltsAttempts} / {u.bestIeltsBand?.toFixed(1) ?? "—"}
                </td>
                <td className="py-3 pr-4 text-white/50 text-xs">
                  {new Date(u.lastActiveAt).toLocaleDateString("ru-RU")}
                </td>
                <td className="py-3 relative">
                  <button
                    onClick={() =>
                      setOpenMenuId((id) => (id === u.id ? null : u.id))
                    }
                    className="text-white/40 hover:text-white"
                  >
                    <MoreVertical size={16} />
                  </button>

                  {openMenuId === u.id && (
                    <div className="absolute right-0 top-8 z-10 w-48 glass-panel--aurora p-2 space-y-1">
                      <button
                        onClick={() => onResetPassword(u.id)}
                        className="w-full flex items-center gap-2 text-left text-xs px-3 py-2 rounded-lg hover:bg-white/5"
                      >
                        <KeyRound size={13} /> Сбросить пароль
                      </button>
                      <button
                        onClick={() =>
                          onChangeRole(
                            u.id,
                            u.role === "admin" ? "student" : "admin"
                          )
                        }
                        className="w-full flex items-center gap-2 text-left text-xs px-3 py-2 rounded-lg hover:bg-white/5"
                      >
                        <ShieldCheck size={13} />
                        {u.role === "admin" ? "Снять права admin" : "Сделать admin"}
                      </button>
                    </div>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </GlassCard>
  );
}

function RoleBadge({ role }: { role: UserRole }) {
  const styles: Record<UserRole, string> = {
    student: "bg-white/5 text-white/60",
    moderator: "bg-accent-cyan/10 text-accent-cyan",
    admin: "bg-accent-pink/10 text-accent-pink",
  };
  return (
    <span className={`text-xs px-2 py-1 rounded-full ${styles[role]}`}>{role}</span>
  );
}
