"use client";

import { motion } from "framer-motion";
import { ReactNode } from "react";
import { clsx } from "clsx";

type GlowColor = "violet" | "cyan" | "pink" | "none";

interface GlassCardProps {
  children: ReactNode;
  className?: string;
  glow?: GlowColor;
  aurora?: boolean; // включить неоновую градиентную рамку
  as?: "div" | "article";
}

const glowClassMap: Record<GlowColor, string> = {
  violet: "hover:shadow-glow-violet",
  cyan: "hover:shadow-glow-cyan",
  pink: "hover:shadow-glow-pink",
  none: "",
};

/**
 * GlassCard — базовая стеклянная панель для всей платформы Uniway.
 * Используется для карточек университетов, блоков симулятора, панели админки и т.д.
 */
export default function GlassCard({
  children,
  className,
  glow = "violet",
  aurora = false,
  as = "div",
}: GlassCardProps) {
  const Component = motion[as];

  return (
    <Component
      whileHover={{ y: -4 }}
      transition={{ type: "spring", stiffness: 300, damping: 22 }}
      className={clsx(
        aurora ? "glass-panel--aurora" : "glass-panel",
        "shadow-glass transition-shadow duration-300",
        glowClassMap[glow],
        "p-6",
        className
      )}
    >
      {children}
    </Component>
  );
}
