"use client";

import { ButtonHTMLAttributes } from "react";
import { clsx } from "clsx";

type Variant = "violet" | "cyan" | "pink" | "ghost";

interface GlowButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
}

const variantClasses: Record<Variant, string> = {
  violet:
    "bg-accent-violet/90 hover:bg-accent-violet text-white hover:shadow-glow-violet",
  cyan: "bg-accent-cyan/90 hover:bg-accent-cyan text-space-void hover:shadow-glow-cyan",
  pink: "bg-accent-pink/90 hover:bg-accent-pink text-white hover:shadow-glow-pink",
  ghost:
    "bg-transparent border border-white/15 text-white hover:border-accent-violet/60 hover:shadow-glow-violet",
};

export default function GlowButton({
  variant = "violet",
  className,
  children,
  ...props
}: GlowButtonProps) {
  return (
    <button
      className={clsx(
        "px-5 py-2.5 rounded-xl font-medium text-sm transition-all duration-300",
        "focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2",
        "disabled:opacity-40 disabled:cursor-not-allowed disabled:hover:shadow-none",
        variantClasses[variant],
        className
      )}
      {...props}
    >
      {children}
    </button>
  );
}
