"use client";

import { useEffect, useMemo, useState, useCallback } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Flag, Clock, Calculator, ChevronLeft, ChevronRight, X } from "lucide-react";
import GlassCard from "@/components/ui/GlassCard";
import GlowButton from "@/components/ui/GlowButton";
import DesmosCalculator from "@/components/sat/DesmosCalculator";
import type { SatAttemptState, SatSectionConfig, SatChoice } from "@/types/sat";

interface SatSimulatorProps {
  section: SatSectionConfig;
  onFinish: (state: SatAttemptState) => void;
}

/**
 * SatSimulator — воспроизводит основной UX Bluebook (официальное ПО College Board):
 * - таймер модуля с возможностью скрыть время
 * - панель навигации по вопросам (сетка с цветовой индикацией статуса)
 * - флаг "отметить для проверки"
 * - встроенный калькулятор (Desmos-like) по требованию модуля
 * - линейная навигация Назад/Далее + прямой переход по номеру вопроса
 */
export default function SatSimulator({ section, onFinish }: SatSimulatorProps) {
  const [state, setState] = useState<SatAttemptState>(() => ({
    answers: {},
    statuses: Object.fromEntries(section.questions.map((q) => [q.id, "unseen"])),
    currentIndex: 0,
    timeRemainingSeconds: section.durationSeconds,
  }));
  const [showNavigator, setShowNavigator] = useState(false);
  const [showCalculator, setShowCalculator] = useState(false);
  const [hideTime, setHideTime] = useState(false);

  const currentQuestion = section.questions[state.currentIndex];

  // Таймер обратного отсчёта модуля
  useEffect(() => {
    if (state.timeRemainingSeconds <= 0) {
      onFinish(state);
      return;
    }
    const t = setInterval(() => {
      setState((s) => ({ ...s, timeRemainingSeconds: s.timeRemainingSeconds - 1 }));
    }, 1000);
    return () => clearInterval(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state.timeRemainingSeconds === 0]);

  const formattedTime = useMemo(() => {
    const m = Math.floor(state.timeRemainingSeconds / 60);
    const s = state.timeRemainingSeconds % 60;
    return `${m}:${s.toString().padStart(2, "0")}`;
  }, [state.timeRemainingSeconds]);

  const selectAnswer = useCallback(
    (choiceId: SatChoice["id"]) => {
      setState((s) => ({
        ...s,
        answers: { ...s.answers, [currentQuestion.id]: choiceId },
        statuses: { ...s.statuses, [currentQuestion.id]: "answered" },
      }));
    },
    [currentQuestion]
  );

  const toggleFlag = useCallback(() => {
    setState((s) => {
      const isFlagged = s.statuses[currentQuestion.id] === "flagged";
      const fallback = s.answers[currentQuestion.id] ? "answered" : "unseen";
      return {
        ...s,
        statuses: {
          ...s.statuses,
          [currentQuestion.id]: isFlagged ? fallback : "flagged",
        },
      };
    });
  }, [currentQuestion]);

  const goTo = useCallback((index: number) => {
    setState((s) => ({ ...s, currentIndex: index }));
    setShowNavigator(false);
  }, []);

  const goNext = useCallback(() => {
    if (state.currentIndex < section.questions.length - 1) {
      goTo(state.currentIndex + 1);
    } else {
      onFinish(state);
    }
  }, [state, section.questions.length, goTo, onFinish]);

  const goPrev = useCallback(() => {
    if (state.currentIndex > 0) goTo(state.currentIndex - 1);
  }, [state.currentIndex, goTo]);

  const answeredCount = Object.values(state.statuses).filter(
    (s) => s === "answered"
  ).length;

  return (
    <div className="min-h-screen bg-space-void text-white flex flex-col">
      {/* Верхняя панель — имитация Bluebook header */}
      <header className="flex items-center justify-between px-6 py-3 border-b border-white/10 glass-panel rounded-none">
        <div className="text-sm text-white/60">{section.title}</div>

        <div className="flex items-center gap-4">
          <button
            onClick={() => setHideTime((v) => !v)}
            className="flex items-center gap-2 text-sm px-3 py-1.5 rounded-lg hover:bg-white/5"
          >
            <Clock size={16} className="text-accent-cyan" />
            {hideTime ? "Время скрыто" : formattedTime}
          </button>

          {section.questions[0]?.allowsCalculator && (
            <button
              onClick={() => setShowCalculator((v) => !v)}
              className="flex items-center gap-2 text-sm px-3 py-1.5 rounded-lg hover:bg-white/5"
            >
              <Calculator size={16} className="text-accent-violet" />
              Калькулятор
            </button>
          )}
        </div>

        <GlowButton variant="ghost" onClick={() => onFinish(state)}>
          Завершить модуль
        </GlowButton>
      </header>

      {/* Основная область вопроса */}
      <main className="flex-1 grid grid-cols-1 md:grid-cols-2 gap-6 p-6 overflow-auto">
        {currentQuestion.passage && (
          <GlassCard glow="cyan" className="overflow-auto max-h-[70vh]">
            <p className="whitespace-pre-line leading-relaxed text-white/85">
              {currentQuestion.passage}
            </p>
          </GlassCard>
        )}

        <GlassCard
          glow="violet"
          className={currentQuestion.passage ? "" : "md:col-span-2"}
        >
          <div className="flex items-start justify-between gap-4 mb-4">
            <span className="text-xs px-2 py-1 rounded-full bg-white/5 text-white/60">
              Вопрос {state.currentIndex + 1} / {section.questions.length}
            </span>
            <button
              onClick={toggleFlag}
              className={`flex items-center gap-1.5 text-xs px-2 py-1 rounded-full transition-colors ${
                state.statuses[currentQuestion.id] === "flagged"
                  ? "bg-accent-pink/20 text-accent-pink"
                  : "bg-white/5 text-white/50 hover:text-accent-pink"
              }`}
            >
              <Flag size={13} /> Отметить
            </button>
          </div>

          <p className="text-lg mb-6">{currentQuestion.prompt}</p>

          <div className="space-y-3">
            {currentQuestion.choices.map((choice) => {
              const selected = state.answers[currentQuestion.id] === choice.id;
              return (
                <button
                  key={choice.id}
                  onClick={() => selectAnswer(choice.id)}
                  className={`w-full text-left flex items-center gap-3 p-3 rounded-xl border transition-all ${
                    selected
                      ? "border-accent-violet bg-accent-violet/10 shadow-glow-violet"
                      : "border-white/10 hover:border-white/25 hover:bg-white/5"
                  }`}
                >
                  <span
                    className={`w-7 h-7 flex items-center justify-center rounded-full text-sm border ${
                      selected
                        ? "bg-accent-violet border-accent-violet"
                        : "border-white/25"
                    }`}
                  >
                    {choice.id}
                  </span>
                  <span className="text-sm text-white/90">{choice.text}</span>
                </button>
              );
            })}
          </div>
        </GlassCard>
      </main>

      {/* Нижняя панель — навигация + вызов сетки вопросов, как в Bluebook */}
      <footer className="flex items-center justify-between px-6 py-3 border-t border-white/10 glass-panel rounded-none">
        <button
          onClick={goPrev}
          disabled={state.currentIndex === 0}
          className="flex items-center gap-1 text-sm text-white/70 disabled:opacity-30"
        >
          <ChevronLeft size={18} /> Назад
        </button>

        <button
          onClick={() => setShowNavigator(true)}
          className="text-sm px-4 py-2 rounded-lg glass-panel--aurora"
        >
          Вопрос {state.currentIndex + 1} из {section.questions.length} · Отвечено{" "}
          {answeredCount}
        </button>

        <button onClick={goNext} className="flex items-center gap-1 text-sm text-accent-cyan">
          {state.currentIndex === section.questions.length - 1 ? "Завершить" : "Далее"}{" "}
          <ChevronRight size={18} />
        </button>
      </footer>

      {/* Модалка калькулятора */}
      <AnimatePresence>
        {showCalculator && (
          <DesmosCalculator onClose={() => setShowCalculator(false)} />
        )}
      </AnimatePresence>

      {/* Навигатор по вопросам (grid) */}
      <AnimatePresence>
        {showNavigator && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/70 flex items-end md:items-center justify-center z-50"
            onClick={() => setShowNavigator(false)}
          >
            <motion.div
              initial={{ y: 40, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 40, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="glass-panel--aurora w-full md:w-[520px] max-h-[80vh] overflow-auto p-6 rounded-t-2xl md:rounded-2xl"
            >
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-display text-lg">Навигатор вопросов</h3>
                <button onClick={() => setShowNavigator(false)}>
                  <X size={18} className="text-white/60" />
                </button>
              </div>

              <div className="flex gap-4 text-xs text-white/60 mb-4">
                <LegendDot color="bg-accent-violet" label="Отвечен" />
                <LegendDot color="bg-accent-pink" label="Отмечен" />
                <LegendDot color="bg-white/10" label="Не отвечен" />
              </div>

              <div className="grid grid-cols-6 gap-2">
                {section.questions.map((q, i) => {
                  const status = state.statuses[q.id];
                  return (
                    <button
                      key={q.id}
                      onClick={() => goTo(i)}
                      className={`aspect-square rounded-lg text-sm flex items-center justify-center border transition-all ${
                        status === "answered"
                          ? "bg-accent-violet/80 border-accent-violet"
                          : status === "flagged"
                          ? "bg-accent-pink/70 border-accent-pink"
                          : "bg-white/5 border-white/10"
                      } ${state.currentIndex === i ? "ring-2 ring-accent-cyan" : ""}`}
                    >
                      {i + 1}
                    </button>
                  );
                })}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function LegendDot({ color, label }: { color: string; label: string }) {
  return (
    <div className="flex items-center gap-1.5">
      <span className={`w-3 h-3 rounded-full ${color}`} />
      {label}
    </div>
  );
}
