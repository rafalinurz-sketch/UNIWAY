"use client";

import { motion } from "framer-motion";
import { X } from "lucide-react";

interface DesmosCalculatorProps {
  onClose: () => void;
}

/**
 * DesmosCalculator — вызываемый графический калькулятор для Math-модуля.
 * В проде: встроить Desmos API (https://www.desmos.com/api/v1.9/docs/index.html)
 * через <script src="https://www.desmos.com/api/v1.9/calculator.js"> и
 * Desmos.GraphingCalculator(container). Здесь — контейнер + заглушка рендера,
 * чтобы не тянуть внешний скрипт в этот файл напрямую.
 */
export default function DesmosCalculator({ onClose }: DesmosCalculatorProps) {
  return (
    <motion.div
      drag
      dragMomentum={false}
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      className="fixed top-24 right-8 w-[380px] h-[460px] z-50 glass-panel--aurora shadow-glow-violet cursor-move"
    >
      <div className="flex items-center justify-between px-4 py-2 border-b border-white/10 cursor-move">
        <span className="text-sm text-white/70">Графический калькулятор</span>
        <button onClick={onClose} aria-label="Закрыть калькулятор">
          <X size={16} className="text-white/60 hover:text-white" />
        </button>
      </div>
      {/* Контейнер под Desmos.GraphingCalculator(el) в реальной интеграции */}
      <div
        id="desmos-calculator-container"
        className="w-full h-[calc(100%-40px)] bg-white rounded-b-2xl"
      />
    </motion.div>
  );
}
