"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronLeft, ChevronRight, Volume2, Shuffle, Check, X } from "lucide-react";
import GlassCard from "@/components/ui/GlassCard";
import GlowButton from "@/components/ui/GlowButton";

export interface VocabCard {
  id: string;
  term: string;
  partOfSpeech: string; // "n.", "v.", "adj." и т.д.
  definition: string;
  example: string;
  synonyms: string[];
  examTag: "SAT" | "IELTS";
}

interface FlashcardGeneratorProps {
  cards: VocabCard[];
  onProgress?: (knownIds: string[], unknownIds: string[]) => void;
}

/**
 * FlashcardGenerator — интерактивные карточки для запоминания академической
 * лексики. Флип-анимация на Framer Motion (3D transform), self-report
 * "знаю / не знаю" для интервального повторения (spaced repetition на бэкенде).
 */
export default function FlashcardGenerator({
  cards: initialCards,
  onProgress,
}: FlashcardGeneratorProps) {
  const [cards, setCards] = useState(initialCards);
  const [index, setIndex] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const [known, setKnown] = useState<string[]>([]);
  const [unknown, setUnknown] = useState<string[]>([]);

  const card = cards[index];
  const isLast = index === cards.length - 1;

  function next() {
    setFlipped(false);
    if (isLast) {
      onProgress?.(known, unknown);
      return;
    }
    setTimeout(() => setIndex((i) => i + 1), 150);
  }

  function markKnown(isKnown: boolean) {
    if (isKnown) setKnown((k) => [...k, card.id]);
    else setUnknown((u) => [...u, card.id]);
    next();
  }

  function shuffle() {
    setCards((c) => [...c].sort(() => Math.random() - 0.5));
    setIndex(0);
    setFlipped(false);
  }

  function speak(text: string) {
    if (typeof window === "undefined" || !window.speechSynthesis) return;
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = "en-US";
    window.speechSynthesis.speak(utterance);
  }

  if (!card) {
    return (
      <GlassCard className="text-center py-12">
        <p className="text-white/70">Карточки закончились ✨</p>
        <p className="text-sm text-white/50 mt-2">
          Знаю: {known.length} · Учить дальше: {unknown.length}
        </p>
      </GlassCard>
    );
  }

  return (
    <div className="max-w-xl mx-auto">
      <div className="flex items-center justify-between mb-4 text-sm text-white/50">
        <span>
          {index + 1} / {cards.length}
        </span>
        <button onClick={shuffle} className="flex items-center gap-1 hover:text-white">
          <Shuffle size={14} /> Перемешать
        </button>
      </div>

      <div className="[perspective:1200px]">
        <AnimatePresence mode="wait">
          <motion.div
            key={card.id}
            initial={{ opacity: 0, x: 40 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -40 }}
            transition={{ duration: 0.2 }}
          >
            <motion.div
              onClick={() => setFlipped((f) => !f)}
              animate={{ rotateY: flipped ? 180 : 0 }}
              transition={{ duration: 0.5 }}
              style={{ transformStyle: "preserve-3d" }}
              className="relative h-72 cursor-pointer [transform-style:preserve-3d]"
            >
              {/* Лицевая сторона */}
              <div
                style={{ backfaceVisibility: "hidden" }}
                className="absolute inset-0"
              >
                <GlassCard
                  aurora
                  glow="violet"
                  className="h-full flex flex-col items-center justify-center text-center gap-3"
                >
                  <span className="text-xs px-2 py-1 rounded-full bg-white/5 text-accent-cyan">
                    {card.examTag}
                  </span>
                  <h3 className="font-display text-3xl">{card.term}</h3>
                  <span className="text-white/40 text-sm italic">
                    {card.partOfSpeech}
                  </span>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      speak(card.term);
                    }}
                    className="mt-2 text-white/50 hover:text-accent-cyan"
                    aria-label="Прослушать произношение"
                  >
                    <Volume2 size={18} />
                  </button>
                  <p className="text-xs text-white/40 absolute bottom-4">
                    Нажмите, чтобы перевернуть
                  </p>
                </GlassCard>
              </div>

              {/* Обратная сторона */}
              <div
                style={{ backfaceVisibility: "hidden", transform: "rotateY(180deg)" }}
                className="absolute inset-0"
              >
                <GlassCard
                  aurora
                  glow="cyan"
                  className="h-full flex flex-col justify-center gap-3 overflow-auto"
                >
                  <p className="text-white/90">{card.definition}</p>
                  <p className="text-sm text-white/60 italic">"{card.example}"</p>
                  {card.synonyms.length > 0 && (
                    <p className="text-xs text-white/40">
                      Синонимы: {card.synonyms.join(", ")}
                    </p>
                  )}
                </GlassCard>
              </div>
            </motion.div>
          </motion.div>
        </AnimatePresence>
      </div>

      <div className="flex items-center justify-center gap-4 mt-6">
        <GlowButton
          variant="pink"
          className="flex items-center gap-2"
          onClick={() => markKnown(false)}
        >
          <X size={16} /> Не знаю
        </GlowButton>
        <GlowButton
          variant="cyan"
          className="flex items-center gap-2"
          onClick={() => markKnown(true)}
        >
          <Check size={16} /> Знаю
        </GlowButton>
      </div>

      <div className="flex items-center justify-between mt-4 text-white/40">
        <button
          disabled={index === 0}
          onClick={() => {
            setFlipped(false);
            setIndex((i) => Math.max(0, i - 1));
          }}
          className="disabled:opacity-20"
        >
          <ChevronLeft />
        </button>
        <button onClick={next} className="disabled:opacity-20">
          <ChevronRight />
        </button>
      </div>
    </div>
  );
}
