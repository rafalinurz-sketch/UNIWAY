"use client";

import { useState, useRef } from "react";
import { Mic, Square, Send, Loader2 } from "lucide-react";
import GlassCard from "@/components/ui/GlassCard";
import GlowButton from "@/components/ui/GlowButton";
import type { IeltsSkill, IeltsTask, IeltsGradingResult } from "@/types/ielts";

interface IeltsSubmissionProps {
  skill: IeltsSkill;
  task: IeltsTask;
  promptText: string;
  userId: string;
}

/**
 * IeltsSubmission — универсальная форма для Writing (текст) и Speaking (аудио).
 * Отправляет данные на /api/ielts/grade (см. lib/ielts-grading.ts), которая
 * дергает AI API и возвращает разбор по 4 критериям IELTS.
 */
export default function IeltsSubmission({
  skill,
  task,
  promptText,
  userId,
}: IeltsSubmissionProps) {
  const [essayText, setEssayText] = useState("");
  const [isRecording, setIsRecording] = useState(false);
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [result, setResult] = useState<IeltsGradingResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);

  const wordCount = essayText.trim() ? essayText.trim().split(/\s+/).length : 0;

  async function startRecording() {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    const recorder = new MediaRecorder(stream);
    chunksRef.current = [];
    recorder.ondataavailable = (e) => chunksRef.current.push(e.data);
    recorder.onstop = () => {
      setAudioBlob(new Blob(chunksRef.current, { type: "audio/webm" }));
      stream.getTracks().forEach((t) => t.stop());
    };
    recorder.start();
    mediaRecorderRef.current = recorder;
    setIsRecording(true);
  }

  function stopRecording() {
    mediaRecorderRef.current?.stop();
    setIsRecording(false);
  }

  async function handleSubmit() {
    setIsSubmitting(true);
    setError(null);
    try {
      let audioUrl: string | undefined;

      if (skill === "speaking" && audioBlob) {
        // В проде: загрузить в Supabase Storage / S3 и получить публичный URL
        const formData = new FormData();
        formData.append("file", audioBlob, `${userId}-${Date.now()}.webm`);
        const uploadRes = await fetch("/api/uploads/audio", {
          method: "POST",
          body: formData,
        });
        const uploadData = await uploadRes.json();
        audioUrl = uploadData.url;
      }

      const res = await fetch("/api/ielts/grade", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          submission: {
            userId,
            skill,
            task,
            promptText,
            responseText: skill === "writing" ? essayText : undefined,
            audioUrl,
            wordCount: skill === "writing" ? wordCount : undefined,
          },
          bandDescriptors: skill,
        }),
      });

      if (!res.ok) throw new Error("Не удалось получить оценку. Попробуйте ещё раз.");
      const data: IeltsGradingResult = await res.json();
      setResult(data);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Неизвестная ошибка");
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <div className="space-y-6">
      <GlassCard glow="cyan">
        <h3 className="font-display text-lg mb-2">
          {skill === "writing" ? "IELTS Writing" : "IELTS Speaking"} —{" "}
          {task.toUpperCase()}
        </h3>
        <p className="text-white/70 text-sm leading-relaxed">{promptText}</p>
      </GlassCard>

      <GlassCard glow="violet">
        {skill === "writing" ? (
          <>
            <textarea
              value={essayText}
              onChange={(e) => setEssayText(e.target.value)}
              placeholder="Начните писать эссе здесь…"
              className="w-full h-72 bg-transparent border border-white/10 rounded-xl p-4 text-white/90 resize-none focus-visible:outline-2 focus-visible:outline-accent-cyan"
            />
            <div className="flex items-center justify-between mt-3 text-xs text-white/50">
              <span>{wordCount} слов</span>
              <span>
                Task 1: рекомендуется 150+ слов · Task 2: рекомендуется 250+ слов
              </span>
            </div>
          </>
        ) : (
          <div className="flex flex-col items-center gap-4 py-8">
            <button
              onClick={isRecording ? stopRecording : startRecording}
              className={`w-20 h-20 rounded-full flex items-center justify-center transition-all ${
                isRecording
                  ? "bg-accent-pink shadow-glow-pink animate-pulse-glow"
                  : "bg-accent-violet shadow-glow-violet"
              }`}
            >
              {isRecording ? <Square size={26} /> : <Mic size={26} />}
            </button>
            <p className="text-sm text-white/60">
              {isRecording
                ? "Идёт запись… нажмите, чтобы остановить"
                : audioBlob
                ? "Запись готова к отправке"
                : "Нажмите, чтобы начать ответ"}
            </p>
            {audioBlob && (
              <audio controls src={URL.createObjectURL(audioBlob)} className="mt-2" />
            )}
          </div>
        )}

        <GlowButton
          className="mt-5 w-full flex items-center justify-center gap-2"
          disabled={
            isSubmitting ||
            (skill === "writing" ? wordCount === 0 : !audioBlob)
          }
          onClick={handleSubmit}
        >
          {isSubmitting ? (
            <Loader2 size={16} className="animate-spin" />
          ) : (
            <Send size={16} />
          )}
          Отправить на AI-оценку
        </GlowButton>

        {error && <p className="text-accent-pink text-sm mt-3">{error}</p>}
      </GlassCard>

      {result && <IeltsResultView result={result} />}
    </div>
  );
}

function IeltsResultView({ result }: { result: IeltsGradingResult }) {
  const criteriaEntries = Object.entries(result.criteria) as [string, number][];

  return (
    <GlassCard aurora glow="pink" className="space-y-5">
      <div className="flex items-center justify-between">
        <h3 className="font-display text-lg">Результат оценки</h3>
        <span className="text-3xl font-display text-accent-cyan">
          {result.overallBand.toFixed(1)}
        </span>
      </div>

      <div className="grid grid-cols-2 gap-3">
        {criteriaEntries.map(([key, value]) => (
          <div key={key} className="glass-panel p-3">
            <div className="text-xs text-white/50 mb-1">{formatCriterionLabel(key)}</div>
            <div className="text-xl font-display">{value.toFixed(1)}</div>
          </div>
        ))}
      </div>

      <p className="text-sm text-white/80 leading-relaxed">{result.feedback.summary}</p>

      <div className="grid md:grid-cols-2 gap-4">
        <div>
          <h4 className="text-sm font-medium text-accent-cyan mb-2">Сильные стороны</h4>
          <ul className="text-sm text-white/70 space-y-1 list-disc list-inside">
            {result.feedback.strengths.map((s, i) => (
              <li key={i}>{s}</li>
            ))}
          </ul>
        </div>
        <div>
          <h4 className="text-sm font-medium text-accent-pink mb-2">Что улучшить</h4>
          <ul className="text-sm text-white/70 space-y-1 list-disc list-inside">
            {result.feedback.improvements.map((s, i) => (
              <li key={i}>{s}</li>
            ))}
          </ul>
        </div>
      </div>
    </GlassCard>
  );
}

function formatCriterionLabel(key: string) {
  const labels: Record<string, string> = {
    taskAchievement: "Task Achievement",
    coherenceCohesion: "Coherence & Cohesion",
    lexicalResource: "Lexical Resource",
    grammaticalRangeAccuracy: "Grammar Range & Accuracy",
    fluencyCoherence: "Fluency & Coherence",
    pronunciation: "Pronunciation",
  };
  return labels[key] ?? key;
}
