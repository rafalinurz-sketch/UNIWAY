import type { University } from "@/types/university";

export type ChanceCategory = "Safety" | "Target" | "Reach";

export interface UserScores {
  ielts?: number;
  sat?: number;
  gpa?: number;
}

export interface ChanceResult {
  category: ChanceCategory;
  score: number; // 0-100, внутренний индекс уверенности
  reasoning: string[];
}

/**
 * calculateChance — эвристический калькулятор шансов поступления.
 * Не заменяет реальный ML-скоринг, но даёт прозрачную и объяснимую оценку:
 * сравниваем баллы пользователя с минимальными требованиями вуза и его
 * общим acceptance rate, взвешивая три сигнала.
 *
 * Логика по умолчанию (настраивается под ваши данные):
 * - Reach:  пользователь ниже медианных требований ИЛИ acceptance rate < 15%
 * - Target: пользователь на уровне/чуть выше минимальных требований
 * - Safety: пользователь заметно выше требований И acceptance rate > 40%
 */
export function calculateChance(
  university: University,
  scores: UserScores
): ChanceResult {
  const reasoning: string[] = [];
  let signalSum = 0;
  let signalCount = 0;

  const addSignal = (delta: number, label: string) => {
    signalSum += delta;
    signalCount += 1;
    reasoning.push(label);
  };

  const { requirements, acceptanceRatePercent } = university;

  if (requirements.minIeltsOverall && scores.ielts) {
    const diff = scores.ielts - requirements.minIeltsOverall;
    addSignal(
      diff,
      diff >= 0.5
        ? `IELTS ${scores.ielts} выше минимума (${requirements.minIeltsOverall}) на ${diff.toFixed(1)}`
        : diff >= 0
        ? `IELTS ${scores.ielts} соответствует минимуму (${requirements.minIeltsOverall})`
        : `IELTS ${scores.ielts} ниже минимума (${requirements.minIeltsOverall})`
    );
  }

  if (requirements.minSatTotal && scores.sat) {
    const diff = (scores.sat - requirements.minSatTotal) / 100; // нормализация к шкале ~IELTS
    addSignal(
      diff,
      diff >= 0.5
        ? `SAT ${scores.sat} заметно выше минимума (${requirements.minSatTotal})`
        : diff >= 0
        ? `SAT ${scores.sat} на уровне минимума (${requirements.minSatTotal})`
        : `SAT ${scores.sat} ниже минимума (${requirements.minSatTotal})`
    );
  }

  if (requirements.minGpa && scores.gpa) {
    const diff = (scores.gpa - requirements.minGpa) * 2; // GPA чувствительнее — усиливаем вес
    addSignal(
      diff,
      diff >= 0.5
        ? `GPA ${scores.gpa} выше минимума (${requirements.minGpa})`
        : diff >= 0
        ? `GPA ${scores.gpa} на уровне минимума (${requirements.minGpa})`
        : `GPA ${scores.gpa} ниже минимума (${requirements.minGpa})`
    );
  }

  const avgSignal = signalCount > 0 ? signalSum / signalCount : 0;

  // Штраф/бонус за общую избирательность вуза
  const selectivityAdjustment =
    acceptanceRatePercent < 15 ? -0.4 : acceptanceRatePercent > 40 ? 0.3 : 0;

  const finalSignal = avgSignal + selectivityAdjustment;
  reasoning.push(
    `Общий acceptance rate вуза: ${acceptanceRatePercent}% ${
      acceptanceRatePercent < 15
        ? "(высокая избирательность)"
        : acceptanceRatePercent > 40
        ? "(умеренная избирательность)"
        : ""
    }`
  );

  let category: ChanceCategory;
  if (finalSignal < -0.15) category = "Reach";
  else if (finalSignal < 0.6) category = "Target";
  else category = "Safety";

  // score — просто удобный индекс 0-100 для прогресс-баров в UI
  const score = Math.max(5, Math.min(95, Math.round(50 + finalSignal * 40)));

  return { category, score, reasoning };
}
