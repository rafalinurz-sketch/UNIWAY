import type { IeltsGradingRequest, IeltsGradingResult } from "@/types/ielts";

/**
 * gradeIeltsSubmission — серверная функция (вызывать из app/api/ielts/grade/route.ts,
 * НЕ из клиентских компонентов, т.к. использует секретный API-ключ).
 *
 * Промпт жёстко требует ответ только в формате JSON, чтобы результат можно было
 * безопасно распарсить и отрисовать в UI (радар-чарт критериев, комментарии).
 */
export async function gradeIeltsSubmission(
  req: IeltsGradingRequest
): Promise<IeltsGradingResult> {
  const descriptors =
    req.bandDescriptors === "writing"
      ? "Task Achievement/Response, Coherence and Cohesion, Lexical Resource, Grammatical Range and Accuracy"
      : "Fluency and Coherence, Lexical Resource, Grammatical Range and Accuracy, Pronunciation";

  const systemPrompt = `Ты — сертифицированный экзаменатор IELTS. Оценивай строго по официальным band descriptors (0-9, шаг 0.5) по критериям: ${descriptors}.
Отвечай ТОЛЬКО валидным JSON без markdown-разметки, без пояснений вне JSON, по следующей схеме:
{
  "overallBand": number,
  "criteria": { <4 ключа критериев с числовыми band-оценками> },
  "feedback": {
    "summary": string,
    "strengths": string[],
    "improvements": string[],
    "correctedExamples": [{ "original": string, "suggestion": string, "reason": string }]
  }
}`;

  const userContent = `Задание (${req.submission.task}): ${req.submission.promptText}

Ответ студента:
${req.submission.responseText ?? "(транскрипт прикреплён отдельно из аудио)"}

${req.submission.wordCount ? `Количество слов: ${req.submission.wordCount}` : ""}`;

  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": process.env.ANTHROPIC_API_KEY as string,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({
      // Актуальная модель на момент написания — сверьте с docs.claude.com/en/docs/about-claude/models
      model: "claude-sonnet-5",
      max_tokens: 2000,
      system: systemPrompt,
      messages: [{ role: "user", content: userContent }],
    }),
  });

  if (!response.ok) {
    throw new Error(`AI grading request failed: ${response.status}`);
  }

  const data = await response.json();
  const rawText: string = data.content
    .filter((block: { type: string }) => block.type === "text")
    .map((block: { text: string }) => block.text)
    .join("\n");

  const cleaned = rawText.replace(/```json|```/g, "").trim();
  const parsed = JSON.parse(cleaned);

  return {
    ...parsed,
    gradedAt: new Date().toISOString(),
    modelVersion: "claude-sonnet-5",
  } as IeltsGradingResult;
}
